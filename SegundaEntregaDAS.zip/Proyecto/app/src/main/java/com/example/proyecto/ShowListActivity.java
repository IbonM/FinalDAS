package com.example.proyecto;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ShowListActivity extends AppCompatActivity {

    private static final String TAG = "ShowListActivity";
    Database db;
    private ListView listView;
    private LayoutInflater inflater;
    ImageView iv;
    ArrayList<String> list;
    ArrayList<String> list2;
    ArrayList<Boolean> list3;
    ListAdapter adapter;

    @Override
    protected void onCreate(@Nullable Bundle instanceState){
        super.onCreate(instanceState);
        setContentView(R.layout.showlist);
        listView= findViewById(R.id.listView);
        iv= findViewById(R.id.imageView);
        db = new Database(this);
        final AlertDialog.Builder builder= new AlertDialog.Builder(this);
        fillList();
        //Click sobre un elemento, muestra un dialog para eliminarlo o cambiar el valor de shiny
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, final int pos, long id){
                final TextView item = view.findViewById(R.id.textView);
                final CheckBox check = view.findViewById(R.id.check);
                //toast(String.valueOf(pos));
                toast((String) item.getText());
                builder.setTitle((R.string.options));
                builder.setMessage((R.string.optMsg));
                builder.setCancelable(true);
                builder.setPositiveButton(
                        (R.string.delete),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                delete((String) item.getText());
                                fillList();
                            }
                        });
                builder.setNeutralButton(
                        (R.string.cancel),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                dialog.dismiss();
                            }
                        });
                builder.setNegativeButton(
                        (R.string.shiny),
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                shiny((String) item.getText(),check.isChecked());
                                fillList();
                            }
                        });
                AlertDialog alert = builder.create();
                alert.show();

            }
        });

    }
    //Mostrar elementos de la base de datos
    private void fillList() {

        list = new ArrayList<>();
        list2 = new ArrayList<>();
        list3 = new ArrayList<>();
        //list4 = new int[]{R.drawable.missing};
        Log.d(TAG, "filling list");
        String b;
        Cursor data = db.showAll();
        inflater = (LayoutInflater) this.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        Log.d(TAG, "filling list "+data.getCount());
        if (data.getCount() != 0) {
            while (data.moveToNext()) {
                list.add(data.getString(1));
                list2.add(data.getString(2));
                list3.add(data.getInt(3)>0);

            }
        }
            adapter = new CustomAdapter();
            listView.setAdapter(adapter);
    }
    //Mostrar mensaje mediante Toast
    private void toast(String msg){
        Toast aviso = Toast.makeText(this,msg,Toast.LENGTH_SHORT);
        aviso.setGravity(Gravity.TOP| Gravity.CENTER, 10, 10);
        aviso.show();
    }
    //Eliminar elemento de la base de datos
    public void delete(String txt){
        if (db.delete(txt)){
            toast(getString(R.string.success));
        }
        else{
            toast("Error");
        }
    }

    //Cambiar el valor de Shiny del elemento en la base de datos
    public void shiny(String txt,Boolean b){
        if (db.shiny(txt, b)){
            toast(getString(R.string.success));
        }
        else{
            toast("Error");
        }
    }
    //Lista personalizada
    class CustomAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return list.size();
        }

        @Override
        public Object getItem(int position) {
            return null;
        }

        @Override
        public long getItemId(int position) {
            return 0;
        }

        @Override
        public View getView(int pos, View convertView, ViewGroup parent) {
            convertView = inflater.inflate(R.layout.customlist,null);

            TextView linea1 = convertView.findViewById(R.id.textView);
            TextView linea2 = convertView.findViewById(R.id.textView2);
            CheckBox check = convertView.findViewById(R.id.check);
            ImageView iv = convertView.findViewById(R.id.imageView);

            linea1.setText(list.get(pos));
            linea2.setText(list2.get(pos));
            check.setChecked(list3.get(pos));
            //Asignar imagen en funcion del nombre
            int resourceId = getApplicationContext().getResources().getIdentifier(list.get(pos).toLowerCase(),"drawable",getApplicationContext().getPackageName());
            if (resourceId==0){
                iv.setImageResource(R.drawable.missing);
            }
            else{
                iv.setImageDrawable(getApplicationContext().getResources().getDrawable(resourceId));
            }
            return convertView;
        }
    }
}
