package com.example.proyecto;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

public class ServicioFirebase extends FirebaseMessagingService {
    public ServicioFirebase() {
    }

    //Metodo que se ejecuta al crear un nuevo token, al instalar la aplicacion o borrar sus datos
    //Suscribe al tema DAS para poder recibir notificaciones mediante fcm.php
    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
        FirebaseMessaging.getInstance().subscribeToTopic("DAS");
        Log.d("TOKEN", "Refreshed token: " + s);
    }

    //Sistema que muestra las notificaciones recibidas por FCM
    public void onMessageReceived(RemoteMessage remoteMessage) {
        NotificationManager elManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationCompat.Builder elBuilder = new NotificationCompat.Builder(this, "ChannelID");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel elCanal = new NotificationChannel("ChannelID", "ChannelName", NotificationManager.IMPORTANCE_DEFAULT);
            elBuilder.setSmallIcon(R.drawable.pikachu)
                    .setVibrate(new long[]{0, 1000, 500, 1000})
                    .setAutoCancel(true);
            elCanal.setDescription("Channel Description");
            elCanal.enableLights(true);
            elCanal.setLightColor(Color.RED);
            elCanal.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            elCanal.enableVibration(true);
            elManager.createNotificationChannel(elCanal);
        }
        if (remoteMessage.getNotification() != null) {
            elBuilder.setSmallIcon(R.drawable.pikachu)
                    .setContentTitle(remoteMessage.getNotification().getTitle())
                    .setContentText(remoteMessage.getNotification().getBody())
                    .setSubText("");
            elManager.notify(1, elBuilder.build());
        }
    }
}
