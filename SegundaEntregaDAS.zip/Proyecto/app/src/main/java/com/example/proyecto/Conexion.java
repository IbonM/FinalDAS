package com.example.proyecto;

import android.content.Context;

import androidx.annotation.NonNull;
import androidx.work.Data;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.net.ssl.HttpsURLConnection;

public class Conexion extends Worker {


    public Conexion(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    //funciona en segundo plano y se encarga de realizar la conexión con el servidor enviándole los parámetros recibidos y devuelve la respuesta del servidor
    @NonNull
    @Override
    public Result doWork() {
        Context cont= MainActivity.getContext();
        String line, result = "";
        HttpsURLConnection urlConnection = GeneradorConexionesSeguras.getInstance().crearConexionSegura(cont, "https://134.209.235.115/imariscal002/WEB/servicioweb.php");
        try {
            JSONObject parametrosJSON = new JSONObject();
            parametrosJSON.put("User",  getInputData().getString("User"));
            parametrosJSON.put("Pass",  getInputData().getString("Pass"));

            urlConnection.setRequestProperty("Content-Type","application/json");

            PrintWriter out = new PrintWriter(urlConnection.getOutputStream());
            out.print(parametrosJSON.toString());
            out.close();

            int statusCode = urlConnection.getResponseCode();
            if (statusCode == 200) {
                BufferedInputStream inputStream = new BufferedInputStream(urlConnection.getInputStream());
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "UTF-8"));
                while ((line = bufferedReader.readLine()) != null) {
                    result += line;
                }
                inputStream.close();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        Data resultados = new Data.Builder()
                .putString("resultado",result)
                .build();
        return Result.success(resultados);
    }
}
