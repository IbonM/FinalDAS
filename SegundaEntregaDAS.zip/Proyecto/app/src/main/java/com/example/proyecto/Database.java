package com.example.proyecto;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;



public class Database extends SQLiteOpenHelper {

    private static final String TAG = "Database";
    private static final String tablename = "table_1";
    private static final String tablename2 = "table_2";
    private static final String col1 = "ID";
    private static final String col2 = "Name";
    private static final String col3 = "Descr";
    private static final String col4 = "Shiny";

    public Database(Context context){
        super(context, tablename, null, 1);
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + tablename + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " + col2 + " SPECIES," + col3 + " DESCRIPTION," + col4 + " SHINY)";
        db.execSQL(createTable);
        String createTable2 = "CREATE TABLE " + tablename2 + " (ID INTEGER PRIMARY KEY AUTOINCREMENT, " + col2 + " USER," + col3 + " PASS)";
        db.execSQL(createTable2);

        //Crear un usuario predeterminado
        ContentValues contentValues = new ContentValues();
        contentValues.put(col2,"A");
        contentValues.put(col3,"B");
        db.insert(tablename2,null,contentValues);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + tablename);
        onCreate(db);
    }
    //Eliminar todos los elementos de las bases de datos
    public void deleteAll() {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DROP TABLE IF EXISTS " + tablename);
        db.execSQL("DROP TABLE IF EXISTS " + tablename2);
        onCreate(db);
    }
    //Anadir elemento a la base de datos
    public int  add(String item, String item2, Boolean b){
        item = item.toLowerCase();
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery("SELECT * FROM " + tablename+ " WHERE "+col2+" = '" + item+"'", null);
        if (c.getCount() == 0){
            ContentValues contentValues = new ContentValues();
            contentValues.put(col2,item);
            contentValues.put(col3,item2);
            contentValues.put(col4,b);
            Log.d(TAG, "add: adding "+item+" to "+tablename);
            if (db.insert(tablename,null,contentValues) == -1) {
                return 0;}
            else {
                return 1;}
        }
        else{
            return 2;}
    }
    //Eliminar elemento de la base de datos
    public boolean delete(String txt){

        SQLiteDatabase db = this.getWritableDatabase();
        String[] txt2= txt.split(" ");
        Log.d(TAG, "add: removing :  "+txt2[0]+" from "+tablename);
        if (db.delete(tablename,col2+"=?",new String[]{txt2[0]})>0 ){
            return true;
        }
        else {
            return false;
        }
    }

    //Cambiar el valor de Shiny del elemento en la base de datos
    public boolean shiny(String txt, Boolean b){
        SQLiteDatabase db = this.getWritableDatabase();

        if (b){
            db.execSQL("UPDATE " + tablename+" SET "+col4+ " = '"+0+"' WHERE "+col2+" = '"+txt+"';");
        }
        else{
            db.execSQL("UPDATE " + tablename+" SET "+col4+ " = '"+1+"' WHERE "+col2+" = '"+txt+"';");
        }
        return true;
    }

    //Devuelve true si los credenciales son correctos
    public boolean login(String txt, String pass){

        SQLiteDatabase db = this.getWritableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + tablename2+ " WHERE "+col2+" = '" + txt+"' AND "+col3+" = '"+pass+"'", null);
        return (c.getCount() > 0);

    }

    //Devuelve todos los elementos de la base de datos
    public Cursor showAll(){
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor c = db.rawQuery("SELECT * FROM " + tablename, null);
        return c;
    }
}
