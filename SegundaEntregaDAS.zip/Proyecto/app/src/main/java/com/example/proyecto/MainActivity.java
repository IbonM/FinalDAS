package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Observer;
import androidx.work.Data;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkInfo;
import androidx.work.WorkManager;

import android.Manifest;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;

import android.widget.Toast;

import com.example.proyecto.ui.login.LoginActivity;

import com.google.firebase.iid.FirebaseInstanceId;

import java.util.Locale;


public class MainActivity extends AppCompatActivity {

    private static Context context;
    private static final String TAG = "MainActivity";
    private final int MY_PERMISSIONS_REQUEST_CAMERA = 1;
    static final int CODIGO_FOTO = 1;
    Database db;
    private Button b1, b2, bEsp, bEng, bLogin, bCamera;
    private CheckBox box;
    private ImageView elImageView;
    private EditText t1, t2;
    ConstraintLayout layout;
    NotificationManager elManager;
    NotificationCompat.Builder elBuilder;
    static String user,aux;
    LoginActivity la;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        context = this;
        FirebaseInstanceId.getInstance().getInstanceId();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout = findViewById(R.id.layout);
        elImageView = findViewById(R.id.imageView2);
        t1 = (EditText) findViewById(R.id.t1);
        t2 = (EditText) findViewById(R.id.t2);
        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        bCamera = (Button) findViewById(R.id.camera);
        bEsp = (Button) findViewById(R.id.bEsp);
        bEng = (Button) findViewById(R.id.bEng);
        bLogin = (Button) findViewById(R.id.bLogin);
        box = (CheckBox) findViewById(R.id.box);
        user = "";
        aux = "";
        db = new Database(this);
        la = new LoginActivity();
        elImageView.setImageResource(R.drawable.dex);

        //Boton ADD (Anadir a la base de datos)
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (user != "") {
                    String entry = t1.getText().toString().replaceAll("\\s+", "");
                    String entry2 = t2.getText().toString();
                    if (t1.length() == 0) {
                        toast(getString((R.string.emptyField)));
                    } else {
                        add(entry, entry2, box.isChecked());
                        t1.setText("");
                        t2.setText("");
                        box.setChecked(false);
                    }
                } else {
                    toast(getString((R.string.mustLog)));
                }
            }
        });
        //Boton SHOW (Mostrar elementos de la base de datos)
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ShowListActivity.class);
                startActivity(intent);
            }
        });
        //Boton ESP (Cambiar idioma a espanol)
        bEsp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                elBuilder.setSmallIcon(android.R.drawable.stat_sys_warning)
                        .setContentTitle("Idioma cambiado")
                        .setContentText("La aplicacion se muestra ahora en castellano")
                        .setSubText("");
                elManager.notify(1, elBuilder.build());
                language("es");
            }
        });
        //Boton ENG (Cambiar idioma a ingles)
        bEng.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                elBuilder.setSmallIcon(android.R.drawable.stat_sys_warning)
                        .setContentTitle("Language changed")
                        .setContentText("App is now shown in english")
                        .setSubText("");
                elManager.notify(1, elBuilder.build());
                language("en");
            }
        });
        //Boton Login
        bLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        //Boton Camara
        bCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePicture();

            }

        });
        //Sistema de notificaciones
        elManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        elBuilder = new NotificationCompat.Builder(this, "ChannelID");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel elCanal = new NotificationChannel("ChannelID", "ChannelName", NotificationManager.IMPORTANCE_DEFAULT);
            elBuilder.setSmallIcon(android.R.drawable.stat_sys_warning)
                    .setVibrate(new long[]{0, 1000, 500, 1000})
                    .setAutoCancel(true);
            elCanal.setDescription("Channel Description");
            elCanal.enableLights(true);
            elCanal.setLightColor(Color.RED);
            elCanal.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            elCanal.enableVibration(true);
            elManager.createNotificationChannel(elCanal);
        }

    }

    //Anadir elemento a la base de datos
    public void add(String input, String input2, boolean b) {
        int n = db.add(input, input2, b);
        if (n == 1) {
            toast(getString((R.string.pkmnAdd)));
        } else if (n == 2) {
            toast(getString((R.string.duplicate)));
        } else {
            toast("Error");
        }
    }

    //Llama a actividad de conexion en segundo plano enviando las credenciales introducidas en login y devuelve la respuesta del servidor
    public String loginAccess(String txt, String pass) {

        Data datos = new Data.Builder()
                .putString("User", txt)
                .putString("Pass", pass)
                .build();
        String s = "";
        aux = "";

        OneTimeWorkRequest otwr = new OneTimeWorkRequest.Builder(Conexion.class)
                .setInputData(datos)
                .build();
        WorkManager.getInstance(this).getWorkInfoByIdLiveData(otwr.getId())
                .observe(this, new Observer<WorkInfo>() {
                    @Override
                    public void onChanged(WorkInfo workInfo) {
                        if (workInfo != null && workInfo.getState().isFinished()) {

                            aux = workInfo.getOutputData().getString("resultado");
                            t1.setText(aux);

                        }
                    }
                });
        WorkManager.getInstance(MainActivity.getContext()).enqueue(otwr);
        s = aux;
        return (s);
    }



    //Mostrar mensaje mediante Toast
    private void toast(String msg) {

        Toast aviso = Toast.makeText(this, msg, Toast.LENGTH_SHORT);
        aviso.setGravity(Gravity.TOP | Gravity.CENTER, 0, 10);
        aviso.show();
    }

    //Definir nombre de usuario al logear
    public static void setUser(String pUser) {
        user = pUser;

    }

    //Devolver el contexto de MainActivity
    public static Context getContext() {
        return context;
    }

    //Definir nombre de usuario al logear
    public static String getAux() {
        return aux;
    }

    //Cambiar idioma de la aplicacion
    private void language(String lang) {
        Resources res = getResources();
        Configuration con = res.getConfiguration();
        con.setLocale(new Locale(lang));
        res.updateConfiguration(con, res.getDisplayMetrics());
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }

    //Metodo que se encarga de pedir permisos de camara y llamar a una app de fotografia
    protected void takePicture() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.CAMERA)) {

            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.CAMERA},
                        MY_PERMISSIONS_REQUEST_CAMERA);
                takePicture();
            }
        } else {
            Intent elIntentFoto = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (elIntentFoto.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(elIntentFoto, CODIGO_FOTO);
            }
        }
    }

    //Al sacar la foto, si el codigo de respuesta es correcto, se recortará la foto con forma cuadrada y se trabajara con ella
    //En este momento la unica funcion implementada para la foto es mostrarla para comprobar que hasta ahi funciona correctamente
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CODIGO_FOTO && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            Bitmap cropImg;
            Bitmap laminiatura = (Bitmap) extras.get("data");
            if (laminiatura.getHeight() > laminiatura.getWidth()) {
                cropImg = Bitmap.createBitmap(laminiatura, 0, (laminiatura.getHeight() - laminiatura.getWidth()) / 2, laminiatura.getWidth(), laminiatura.getWidth());
            } else if (laminiatura.getHeight() < laminiatura.getWidth()) {
                cropImg = Bitmap.createBitmap(laminiatura, (laminiatura.getWidth() - laminiatura.getHeight()) / 2, 0, laminiatura.getHeight(), laminiatura.getHeight());
            } else {
                cropImg = laminiatura;
            }
            elImageView.setImageBitmap(cropImg);
        }

    }
}

