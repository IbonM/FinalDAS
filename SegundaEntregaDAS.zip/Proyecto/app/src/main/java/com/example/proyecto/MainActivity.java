package com.example.proyecto;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.proyecto.ui.login.LoginActivity;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    Database db;
    private Button b1,b2,bEsp,bEng,bLogin;
    private CheckBox box;
    private EditText t1,t2;
    ConstraintLayout layout;
    NotificationManager elManager;
    NotificationCompat.Builder elBuilder;
    static String user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        layout = findViewById(R.id.layout);
        t1 = (EditText) findViewById(R.id.t1);
        t2 = (EditText) findViewById(R.id.t2);
        b1 = (Button) findViewById(R.id.b1);
        b2 = (Button) findViewById(R.id.b2);
        bEsp = (Button) findViewById(R.id.bEsp);
        bEng = (Button) findViewById(R.id.bEng);
        bLogin = (Button) findViewById(R.id.bLogin);
        box = (CheckBox) findViewById(R.id.box);
        user = "";
        db = new Database(this);
        //Boton ADD (Anadir a la base de datos)
        b1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
            if (user != ""){
                String entry = t1.getText().toString().replaceAll("\\s+","");
                String entry2 = t2.getText().toString();
                if(t1.length()==0){
                    toast(getString((R.string.emptyField)));
                }
                else{
                    add(entry, entry2, box.isChecked());
                    t1.setText("");
                    t2.setText("");
                    box.setChecked(false);
                }
            }
            else{
                toast(getString((R.string.mustLog)));
            }
        }});
        //Boton SHOW (Mostrar elementos de la base de datos)
        b2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ShowListActivity.class);
                startActivity(intent);
            }
        });
        //Boton ESP (Cambiar idioma a espanol)
        bEsp.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                elBuilder.setSmallIcon(android.R.drawable.stat_sys_warning)
                        .setContentTitle("Idioma cambiado")
                        .setContentText("La aplicacion se muestra ahora en castellano")
                        .setSubText("");
                elManager.notify(1, elBuilder.build());
                language("es");
            }
        });
        //Boton ENG (Cambiar idioma a ingles)
        bEng.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                elBuilder.setSmallIcon(android.R.drawable.stat_sys_warning)
                        .setContentTitle("Language changed")
                        .setContentText("App is now shown in english")
                        .setSubText("");
                elManager.notify(1, elBuilder.build());
                language("en");
            }
        });
        //Boton Login
        bLogin.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
        //Sistema de notificaciones
        elManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        elBuilder= new NotificationCompat.Builder(this, "ChannelID");
        if (Build.VERSION.SDK_INT>= Build.VERSION_CODES.O) {
            NotificationChannel elCanal= new NotificationChannel("ChannelID", "ChannelName", NotificationManager.IMPORTANCE_DEFAULT);
            elBuilder.setSmallIcon(android.R.drawable.stat_sys_warning)
                    .setVibrate(new long[]{0, 1000, 500, 1000})
                    .setAutoCancel(true);
            elCanal.setDescription("Channel Description");
            elCanal.enableLights(true);
            elCanal.setLightColor(Color.RED);
            elCanal.setVibrationPattern(new long[]{0, 1000, 500, 1000});
            elCanal.enableVibration(true);
            elManager.createNotificationChannel(elCanal);
        }

    }

    //Anadir elemento a la base de datos
    public void add(String input,String input2, boolean b){
        int n = db.add(input, input2, b);
        if (n==1){
            toast(getString((R.string.pkmnAdd)));
        }
        else if (n==2){
            toast(getString((R.string.duplicate)));
        }
        else{
            toast("Error");
        }
    }

    //Mostrar mensaje mediante Toast
    private void toast(String msg){

        Toast aviso = Toast.makeText(this,msg,Toast.LENGTH_SHORT);
        aviso.setGravity(Gravity.TOP| Gravity.CENTER, 0, 10);
        aviso.show();
    }

    //Definir nombre de usuario al logear
    public static void setUser(String pUser){
        user = pUser;

    }

    //Cambiar idioma de la aplicacion
    private void language(String lang){
        Resources res = getResources();
        Configuration con = res.getConfiguration();
        con.setLocale(new Locale(lang));
        res.updateConfiguration(con,res.getDisplayMetrics());
        Intent intent = getIntent();
        finish();
        startActivity(intent);
    }

}
